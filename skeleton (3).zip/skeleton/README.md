# w7d4: [NewsReader][description]

* [Live Demo](http://aa-newsreader.herokuapp.com/)

To run locally:

* `bundle install`
* `bundle exec rake db:create db:migrate db:seed`

Three feeds with their entries will be created upon running `rake
db:seed`.

Good luck. Have fun!

[description]: https://github.com/appacademy/backbone-curriculum/blob/master/projects/w7d4-news-reader.md
