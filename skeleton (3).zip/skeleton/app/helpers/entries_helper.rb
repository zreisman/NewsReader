module EntriesHelper
end
